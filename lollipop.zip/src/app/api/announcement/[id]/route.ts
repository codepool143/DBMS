import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { title, message } = await req.json();
    const connection = await db();
    await connection.query(
      'UPDATE announcements SET title = ?, message = ? WHERE id = ?',
      [title, message, params.id]
    );

    return new NextResponse('Announcement updated');
  } catch (err) {
    console.error('PUT Error:', err);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  try {
    const connection = await db();
    await connection.query('DELETE FROM announcements WHERE id = ?', [params.id]);
    return new NextResponse('Announcement deleted');
  } catch (err) {
    console.error('DELETE Error:', err);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}
